
public class MsSQLDataBase implements IDataBase{

	@Override
	public void add() {
		System.out.println("MsSQL ile eklendi");
		
	}

	@Override
	public void insert() {
		System.out.println("MsSQL verileri gösterildi");
		
	}

	@Override
	public void delete() {
		System.out.println("MsSQL veri tabanından silindi");
		
	}

	@Override
	public void update() {
		System.out.println("MsSQL veri tabanında gösterildi");
		
	}

}

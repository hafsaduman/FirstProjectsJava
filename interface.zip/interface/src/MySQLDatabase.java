
public class MySQLDatabase implements IDataBase{

	@Override
	public void add() {
		System.out.println("MYSQL veri tabanına eklendi");
	}

	@Override
	public void insert() {
		System.out.println("MYSQL verileri gösterildi");
	}
		
	

	@Override
	public void delete() {
		System.out.println("MYSQL veri tabanından silindi");
		
	}

	@Override
	public void update() {
		System.out.println("MYSQL veri tabanında güncellendi");
		
	}

}

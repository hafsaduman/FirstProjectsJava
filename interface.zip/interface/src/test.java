
public class test {

	public static void main(String[] args) {
		
		databasemaneger databasemaneger=new databasemaneger();
		databasemaneger.addDatabase(new MySQLDatabase());
	    databasemaneger.insertDatabase(new MsSQLDataBase());
	}
      
}


public class databasemaneger {
   public void addDatabase(IDataBase database) {
	   database.add();
   }
   public void insertDatabase(IDataBase database) {
	   database.insert();
   }
   public void deleteDatabase (IDataBase database) {
	   database.delete();
   }
   public void updateDatabase(IDataBase database) {
	   database.update();
   }
}

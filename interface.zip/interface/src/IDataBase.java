
public interface IDataBase {
 void add();
 void insert();
 void delete();
 void update();
}

package pollymorphizm;

public class test {

	public static void main(String[] args) {
		toyoto obj1=new toyotobenzinli();
	    obj1.yakit();
		
	    toyoto obj2 =new toyotodizel();
		obj2.yakit();
		
		toyoto obj3=new toyotoelektrikli();
		obj3.yakit();

	}

}

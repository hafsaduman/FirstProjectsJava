package pollymorphizm;

public class toyotodizel extends toyoto{
	public void motor(){
		System.out.println("toyoto dizel araclar 1.6 dizel motor kullanır");
		}
   public void yakit() {
	   System.out.println("toyoto dizel araclar eurodizel yakit kullanır");
   }
   public void yakıt(String renk) {
	   System.out.println("toyoto dizel araclar 3 renkte üretilmiştir");
	   
   }
}

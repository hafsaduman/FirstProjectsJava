package pollymorphizm;

public class toyoto {
	public void motor() {
		 System.out.println("toyoto da toyoto marka motor kullanılır");
	 }
    public void yakit() {
   	 System.out.println("toyoto da motora uygun yakıt kullanılır");
    }

}

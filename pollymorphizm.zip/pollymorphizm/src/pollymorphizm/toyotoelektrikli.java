package pollymorphizm;

public class toyotoelektrikli extends toyoto{
	public void motor() {
		System.out.println("toyoto elektrikli araclar elektrik kullanır");
	}
	public void yakit() {
		System.out.println("toyoto elektrikli araclar elektrik kullanır");
	}
}

package pollymorphizm;

public class toyotobenzinli extends toyoto {
    public void motor() {
    	System.out.println("toyoto benzinli araclar 1.4 cevreci motor kullanılır");
    	
    }
    public void yakit() {
    	System.out.println("toyoto benzinli araclar E10 benzin kullanır");
    }
    public void yakıt(double maxtuketim) {
    	System.out.println("toyoto benzinli araclar ortalama 6.8 litre benzin kullanır");
    }
}
